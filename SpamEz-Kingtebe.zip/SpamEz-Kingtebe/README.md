
<h1 align="center">
  SpamEz
</h1>
</div>
<p align="center">
    Script 🙋 by <a href="https://github.com/KINGTEBE-404">Kingtebe-404</a>
</p>


![screen](https://github.com/KINGTEBE-404/SpamEz/blob/Kingtebe/IMG_20210106_143429.jpg)
   ![](https://img.shields.io/badge/Language-2-blue) ![](https://img.shields.io/badge/Python-2.7-green) ![](https://img.shields.io/badge/Size-2.89KB-orange) ![](https://img.shields.io/badge/Relase-20-08-20-brightgreen)

## Install script on Termux
```php
$ pkg update && pkg upgrade
$ pkg install python2
$ pkg install git
$ pip2 install requests
$ pip2 install bs4
$ git clone https://github.com/KINGTEBE-404/SpamEz
$ cd SpamEz
$ python2 spam.py
```

## Informasi Script
+ Unlimited
+ Update 1.3
